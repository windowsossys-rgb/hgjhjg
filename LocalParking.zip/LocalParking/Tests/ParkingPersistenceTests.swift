import Foundation
import Testing
@testable import LocalParking

@MainActor
struct ParkingPersistenceTests {
    @Test func roundTripAndClearAcrossNewPersistenceInstances() throws {
        let suite = "localparking.tests.\(UUID())"
        let defaults = try #require(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let session = fixtureSession(duration: 1800)
        try UserDefaultsParkingPersistence(defaults: defaults).save(session)
        let reopened = UserDefaultsParkingPersistence(defaults: defaults)
        #expect(try reopened.load() == session)
        try reopened.clear()
        #expect(try UserDefaultsParkingPersistence(defaults: defaults).load() == nil)
    }

    @Test func corruptDataIsReportedAndRetained() throws {
        let suite = "localparking.tests.\(UUID())"
        let defaults = try #require(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let corrupt = Data("not a saved session".utf8)
        defaults.set(corrupt, forKey: "localparking.session")
        let persistence = UserDefaultsParkingPersistence(defaults: defaults)
        #expect(throws: ParkingDataError.self) { try persistence.load() }
        #expect(defaults.data(forKey: "localparking.session") == corrupt)
    }

    @Test func invalidSaveDoesNotOverwritePreviousSession() throws {
        let suite = "localparking.tests.\(UUID())"
        let defaults = try #require(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let persistence = UserDefaultsParkingPersistence(defaults: defaults)
        let valid = fixtureSession()
        try persistence.save(valid)
        var invalid = valid
        invalid.spotDescription = String(repeating: "x", count: 501)
        #expect(throws: ParkingDataError.self) { try persistence.save(invalid) }
        #expect(try persistence.load() == valid)
    }

    @Test func newerSchemaIsReportedAndRetained() throws {
        let suite = "localparking.tests.\(UUID())"
        let defaults = try #require(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let persistence = UserDefaultsParkingPersistence(defaults: defaults)
        try persistence.save(fixtureSession())
        let data = try #require(defaults.data(forKey: "localparking.session"))
        var envelope = try #require(JSONSerialization.jsonObject(with: data) as? [String: Any])
        envelope["version"] = 999
        let future = try JSONSerialization.data(withJSONObject: envelope)
        defaults.set(future, forKey: "localparking.session")
        #expect(throws: ParkingDataError.self) { try persistence.load() }
        #expect(defaults.data(forKey: "localparking.session") == future)
    }
}
