import Foundation
import Testing
@testable import LocalParking

struct ParkingSessionTests {
    let start = Date(timeIntervalSince1970: 1_800_000_000)

    @Test func elapsedAndCountdownUseAbsoluteDates() throws {
        let session = fixtureSession(at: start, duration: 3600)
        let restored = try JSONDecoder().decode(ParkingSession.self, from: JSONEncoder().encode(session))
        let later = start.addingTimeInterval(1200)
        #expect(restored.elapsed(at: later) == 1200)
        #expect(restored.meter?.remaining(at: later) == 2400)
        #expect(restored.meter?.remainingFraction(at: later) == 2.0 / 3.0)
        #expect(restored.location == session.location)
        #expect(restored.spotDescription == "P4, Level 2")
    }

    @Test func activeExtensionPreservesUnusedTime() throws {
        var session = fixtureSession(at: start, duration: 3600)
        try session.extendMeter(by: 900, at: start.addingTimeInterval(1800))
        #expect(session.expiryDate == start.addingTimeInterval(4500))
        #expect(session.timerDuration == 4500)
        #expect(session.meter?.startedAt == start)
        #expect(session.elapsed(at: start.addingTimeInterval(1800)) == 1800)
    }

    @Test func expiredExtensionStartsNowAndPreservesParkingStart() throws {
        var session = fixtureSession(at: start, duration: 600)
        let now = start.addingTimeInterval(1800)
        try session.extendMeter(by: 900, at: now)
        #expect(session.expiryDate == now.addingTimeInterval(900))
        #expect(session.timerDuration == 900)
        #expect(session.meter?.remainingFraction(at: now) == 1)
        #expect(session.parkedAt == start)
    }

    @Test func progressClampsAcrossExpiryAndClockRollback() {
        let session = fixtureSession(at: start, duration: 600)
        #expect(session.meter?.remainingFraction(at: start.addingTimeInterval(-500)) == 1)
        #expect(session.elapsed(at: start.addingTimeInterval(-500)) == 0)
        #expect(session.meter?.remainingFraction(at: start.addingTimeInterval(900)) == 0)
        #expect(session.meter?.remaining(at: start.addingTimeInterval(900)) == 0)
    }

    @Test func optionalMeterCanBeAddedLater() throws {
        var session = fixtureSession(at: start)
        #expect(session.expiryDate == nil)
        #expect(MeterAlert.plan(for: session, now: start).isEmpty)
        let later = start.addingTimeInterval(60)
        try session.extendMeter(by: 600, at: later)
        #expect(session.expiryDate == later.addingTimeInterval(600))
        #expect(session.parkedAt == start)
    }

    @Test func notificationPlanHasTwoExactThresholds() {
        let session = fixtureSession(at: start, duration: 1800)
        let alerts = MeterAlert.plan(for: session, now: start)
        #expect(alerts == [MeterAlert(kind: .fiveMinutes, fireDate: start.addingTimeInterval(1500)),
                           MeterAlert(kind: .expired, fireDate: start.addingTimeInterval(1800))])
        #expect(Set(alerts.map(\.identifier)).count == 2)
    }

    @Test func notificationPlanSkipsMissedWarningsAndExpiredSessions() {
        let session = fixtureSession(at: start, duration: 1800)
        #expect(MeterAlert.plan(for: session, now: start.addingTimeInterval(1600)).map(\.kind) == [.expired])
        #expect(MeterAlert.plan(for: session, now: start.addingTimeInterval(1800)).isEmpty)
        #expect(MeterAlert.plan(for: fixtureSession(at: start, duration: 300), now: start).map(\.kind) == [.expired])
        #expect(MeterAlert.plan(for: nil, now: start).isEmpty)
    }

    @Test(arguments: [0.0, -60, 59, 86_401, Double.infinity, Double.nan])
    func invalidDurationsAreRejected(_ duration: Double) {
        #expect(throws: ParkingDataError.self) { try ParkingRules.validate(duration: duration) }
    }

    @Test func rejectsInvalidStoredCoordinatesAndDates() {
        var session = fixtureSession(at: start)
        session.location = ParkingLocation(latitude: 200, longitude: 0, horizontalAccuracy: 10, capturedAt: start, isApproximate: false)
        #expect(!session.isValid)
        #expect(!ParkingRules.isValid(date: Date(timeIntervalSince1970: .infinity)))
    }
}

func fixtureSession(at date: Date = Date(), duration: TimeInterval? = nil) -> ParkingSession {
    ParkingSession(
        id: UUID(), parkedAt: date,
        location: ParkingLocation(latitude: 37.7765, longitude: -122.4167, horizontalAccuracy: 12, capturedAt: date, isApproximate: false),
        spotDescription: "P4, Level 2",
        meter: duration.map { ParkingMeter(startedAt: date, expiryDate: date.addingTimeInterval($0)) }
    )
}
