import Foundation
import Testing
@testable import LocalParking

@MainActor
struct ParkingStoreTests {
    @Test func successfulParkPersistsBeforeAddressLookupAndRequestsMeterAlerts() async throws {
        let persistence = MemoryPersistence()
        let geocoder = SuspendedGeocoder()
        let notifications = RecordingNotifications()
        let store = makeStore(persistence: persistence, geocoder: geocoder, notifications: notifications)
        await store.park(notes: "P4, Level 2", duration: 1800)
        #expect(store.isParked)
        #expect(persistence.saved == store.session)
        #expect(store.parkingLocation?.address == nil)
        try await eventually { geocoder.isWaiting && !store.isUpdatingAlerts }
        #expect(notifications.requestedPermission)
        #expect(notifications.scheduled.count == 2)
        geocoder.finish("Example Street")
        try await eventually { store.parkingLocation?.address == "Example Street" }
    }

    @Test func locationDenialLeavesNoSessionOrNotifications() async {
        let persistence = MemoryPersistence()
        let locator = StubLocator(error: ParkingLocationError.denied)
        let notifications = RecordingNotifications()
        let store = makeStore(persistence: persistence, locator: locator, notifications: notifications)
        await store.park(notes: "", duration: 1800)
        #expect(!store.isParked)
        #expect(!store.isLocating)
        #expect(persistence.saved == nil)
        #expect(store.issue?.offersSettings == true)
        #expect(notifications.calls == 0)
    }

    @Test func persistenceFailureDoesNotAnnounceSavedSpotOrScheduleAlerts() async {
        let persistence = MemoryPersistence()
        persistence.failSave = true
        let notifications = RecordingNotifications()
        let store = makeStore(persistence: persistence, notifications: notifications)
        await store.park(notes: "", duration: 1800)
        #expect(!store.isParked)
        #expect(store.issue != nil)
        #expect(notifications.calls == 0)
    }

    @Test func cancellationBeforeLocationReturnsNeverCommits() async throws {
        let locator = SuspendedLocator()
        let persistence = MemoryPersistence()
        let store = makeStore(persistence: persistence, locator: locator)
        let operation = Task { await store.park(notes: "", duration: nil) }
        try await eventually { locator.isWaiting }
        operation.cancel()
        locator.finish()
        await operation.value
        #expect(!store.isParked)
        #expect(!store.isLocating)
        #expect(persistence.saved == nil)
        #expect(store.issue == nil)
    }

    @Test func lateAddressMergesIntoLatestNotesAndMeter() async throws {
        let geocoder = SuspendedGeocoder()
        let persistence = MemoryPersistence()
        let store = makeStore(persistence: persistence, geocoder: geocoder)
        await store.park(notes: "Old notes", duration: 1800)
        try await eventually { geocoder.isWaiting }
        let originalExpiry = try #require(store.expiryDate)
        store.extendTime(by: 600)
        store.updateNotes("P4, Level 2")
        geocoder.finish("Example Street")
        try await eventually { store.parkingLocation?.address == "Example Street" }
        #expect(store.expiryDate == originalExpiry.addingTimeInterval(600))
        #expect(store.spotDescription == "P4, Level 2")
        #expect(persistence.saved == store.session)
    }

    @Test func unparkWinsOverInFlightNotificationScheduling() async throws {
        let notifications = RecordingNotifications()
        notifications.suspendNextCall = true
        let persistence = MemoryPersistence()
        let store = makeStore(persistence: persistence, notifications: notifications)
        await store.park(notes: "", duration: 1800)
        try await eventually { notifications.isWaiting }
        store.unpark()
        notifications.resume()
        try await eventually { !store.isUpdatingAlerts }
        #expect(store.session == nil)
        #expect(persistence.saved == nil)
        #expect(notifications.scheduled.isEmpty)
        #expect(notifications.calls == 2)
        #expect(store.alertStatus == .inactive)
    }

    @Test func rapidExtensionsLeaveOnlyTheLatestSchedule() async throws {
        let notifications = RecordingNotifications()
        notifications.suspendNextCall = true
        let store = makeStore(notifications: notifications)
        await store.park(notes: "", duration: 1800)
        try await eventually { notifications.isWaiting }
        store.extendTime(by: 600)
        store.extendTime(by: 900)
        let latest = try #require(store.expiryDate)
        notifications.resume()
        try await eventually { !store.isUpdatingAlerts }
        #expect(notifications.scheduled.last?.fireDate == latest)
        #expect(notifications.scheduled.count == 2)
    }

    @Test func foregroundRefreshDoesNotPromptForPermission() async throws {
        let persistence = MemoryPersistence()
        persistence.saved = fixtureSession(duration: 1800)
        let notifications = RecordingNotifications()
        let store = makeStore(persistence: persistence, notifications: notifications)
        store.refresh()
        try await eventually { !store.isUpdatingAlerts }
        #expect(!notifications.requestedPermission)
        #expect(store.isParked)
    }

    @Test func failedClearKeepsTheSavedSession() {
        let persistence = MemoryPersistence()
        persistence.saved = fixtureSession()
        persistence.failClear = true
        let store = makeStore(persistence: persistence)
        store.unpark()
        #expect(store.isParked)
        #expect(store.session == persistence.saved)
        #expect(store.issue != nil)
    }

    private func makeStore(
        persistence: MemoryPersistence = MemoryPersistence(),
        locator: any ParkingLocating = StubLocator(),
        geocoder: any ParkingGeocoding = StubGeocoder(),
        notifications: RecordingNotifications = RecordingNotifications()
    ) -> ParkingStore {
        ParkingStore(persistence: persistence, locator: locator, geocoder: geocoder, notifications: notifications)
    }
}

@MainActor
private final class MemoryPersistence: ParkingPersisting {
    var saved: ParkingSession?
    var failSave = false
    var failClear = false
    func load() throws -> ParkingSession? { saved }
    func save(_ session: ParkingSession) throws {
        if failSave { throw ParkingDataError.invalidSession }
        saved = session
    }
    func clear() throws {
        if failClear { throw ParkingDataError.invalidSession }
        saved = nil
    }
}

@MainActor
private final class StubLocator: ParkingLocating {
    let error: (any Error)?
    init(error: (any Error)? = nil) { self.error = error }
    func currentLocation() async throws -> ParkingLocation {
        if let error { throw error }
        return fixtureSession().location
    }
}

@MainActor
private final class SuspendedLocator: ParkingLocating {
    private var continuation: CheckedContinuation<ParkingLocation, any Error>?
    var isWaiting: Bool { continuation != nil }
    func currentLocation() async throws -> ParkingLocation {
        try await withCheckedThrowingContinuation { continuation = $0 }
    }
    func finish() {
        continuation?.resume(returning: fixtureSession().location)
        continuation = nil
    }
}

@MainActor
private final class StubGeocoder: ParkingGeocoding {
    func address(for location: ParkingLocation) async -> String? { nil }
}

@MainActor
private final class SuspendedGeocoder: ParkingGeocoding {
    private var continuation: CheckedContinuation<String?, Never>?
    var isWaiting: Bool { continuation != nil }
    func address(for location: ParkingLocation) async -> String? {
        await withCheckedContinuation { continuation = $0 }
    }
    func finish(_ address: String?) {
        continuation?.resume(returning: address)
        continuation = nil
    }
}

@MainActor
private final class RecordingNotifications: MeterNotifying {
    var calls = 0
    var requestedPermission = false
    var scheduled: [MeterAlert] = []
    var suspendNextCall = false
    private var continuation: CheckedContinuation<Void, Never>?
    var isWaiting: Bool { continuation != nil }
    func invalidate() { scheduled = [] }
    func reconcile(session: ParkingSession?, requestPermission: Bool, isCurrent: @escaping @MainActor () -> Bool) async -> MeterAlertStatus {
        calls += 1
        requestedPermission = requestedPermission || requestPermission
        if suspendNextCall {
            suspendNextCall = false
            await withCheckedContinuation { continuation = $0 }
        }
        guard isCurrent() else { return .inactive }
        scheduled = MeterAlert.plan(for: session, now: Date())
        return scheduled.isEmpty ? .inactive : .scheduled
    }
    func resume() { continuation?.resume(); continuation = nil }
}

/// Bounded waiting for independent main-actor tasks, without relying on arbitrary yield counts.
@MainActor
private func eventually(_ condition: () -> Bool) async throws {
    let deadline = ContinuousClock.now.advanced(by: .seconds(2))
    while !condition() {
        guard ContinuousClock.now < deadline else { throw TestWaitError.timedOut }
        try await Task.sleep(for: .milliseconds(10))
    }
}

private enum TestWaitError: Error { case timedOut }
