import MapKit
import SwiftUI

@MainActor
struct ParkingCard<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        content
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(20)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
    }
}

@MainActor
struct ParkingTimeCard: View {
    let session: ParkingSession
    let now: Date

    var body: some View {
        ParkingCard {
            VStack(alignment: .leading, spacing: 18) {
                Label("Parked for", systemImage: "car.fill").font(.subheadline).foregroundStyle(.secondary)
                Text(ParkingFormat.clock(session.elapsed(at: now)))
                    .font(.system(.largeTitle, design: .rounded, weight: .bold))
                    .monospacedDigit()
                    .contentTransition(.numericText())
                    .accessibilityLabel("Elapsed parking time")
                    .accessibilityValue(ParkingFormat.duration(session.elapsed(at: now)))
                Text("Saved \(session.parkedAt.formatted(date: .abbreviated, time: .shortened))")
                    .font(.footnote).foregroundStyle(.secondary)

                if let meter = session.meter {
                    Divider()
                    let expired = now >= meter.expiryDate
                    let remaining = meter.remaining(at: now)
                    let tint: Color = expired || remaining <= 300 ? .orange : .teal
                    Label(expired ? "Meter expired" : "Meter remaining", systemImage: expired ? "exclamationmark.circle.fill" : "timer")
                        .font(.headline).foregroundStyle(tint)
                    Text(expired ? "Expired \(ParkingFormat.duration(now.timeIntervalSince(meter.expiryDate))) ago" : ParkingFormat.clock(remaining, roundsUp: true))
                        .font(.system(.title, design: .rounded, weight: .semibold))
                        .monospacedDigit()
                        .accessibilityLabel(expired ? "Meter expired" : "Time remaining")
                        .accessibilityValue(expired ? ParkingFormat.duration(now.timeIntervalSince(meter.expiryDate)) + " ago" : ParkingFormat.duration(remaining))
                    ProgressView(value: meter.remainingFraction(at: now), total: 1)
                        .tint(tint)
                        .accessibilityLabel("Meter time remaining")
                        .accessibilityValue("\(Int(meter.remainingFraction(at: now) * 100)) percent")
                    Text("\(expired ? "Expired" : "Expires") \(meter.expiryDate.formatted(date: .abbreviated, time: .shortened))")
                        .font(.footnote).foregroundStyle(.secondary)
                } else {
                    Label("No meter timer", systemImage: "timer").font(.footnote).foregroundStyle(.secondary)
                }
            }
        }
    }
}

@MainActor
struct ParkingSpotCard: View {
    let session: ParkingSession
    let editNotes: () -> Void

    private var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: session.location.latitude, longitude: session.location.longitude)
    }

    var body: some View {
        ParkingCard {
            VStack(alignment: .leading, spacing: 16) {
                Label("Your saved spot", systemImage: "mappin.and.ellipse").font(.headline)
                Map(initialPosition: .region(MKCoordinateRegion(center: coordinate, latitudinalMeters: min(20_000, max(350, session.location.horizontalAccuracy * 3)), longitudinalMeters: min(20_000, max(350, session.location.horizontalAccuracy * 3)))), interactionModes: []) {
                    Marker("Parked here", systemImage: "car.fill", coordinate: coordinate).tint(.teal)
                }
                .id(session.id)
                .frame(height: 180)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .accessibilityLabel("Map of your saved parking location")

                Text(session.location.address ?? "Saved GPS location")
                    .font(.headline).textSelection(.enabled)
                Text("\(session.location.latitude.formatted(.number.precision(.fractionLength(5)))), \(session.location.longitude.formatted(.number.precision(.fractionLength(5))))")
                    .font(.caption.monospaced()).foregroundStyle(.secondary).textSelection(.enabled)
                Text("Reported accuracy: about \(session.location.horizontalAccuracy.formatted(.number.precision(.fractionLength(0)))) m")
                    .font(.caption).foregroundStyle(.secondary)
                if session.location.isApproximate || session.location.horizontalAccuracy > 100 {
                    Label("This location is approximate. Add a level, bay number, or landmark to help find your car.", systemImage: "location.slash")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Divider()
                Text(session.spotDescription.isEmpty ? "No spot notes yet" : session.spotDescription)
                    .foregroundStyle(session.spotDescription.isEmpty ? .secondary : .primary)
                    .textSelection(.enabled)
                Button(action: editNotes) {
                    Label(session.spotDescription.isEmpty ? "Add notes" : "Edit notes", systemImage: "square.and.pencil")
                }
                .frame(minHeight: 44)
                .tint(.teal)
            }
        }
    }
}

enum ParkingFormat {
    static func duration(_ seconds: TimeInterval) -> String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = seconds >= 86_400 ? [.day, .hour, .minute] : [.hour, .minute, .second]
        formatter.unitsStyle = .full
        formatter.maximumUnitCount = 2
        return formatter.string(from: max(0, seconds)) ?? "0 seconds"
    }

    static func clock(_ seconds: TimeInterval, roundsUp: Bool = false) -> String {
        let total = Int(max(0, roundsUp ? ceil(seconds) : floor(seconds)))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let remainder = total % 60
        return hours > 0 ? String(format: "%d:%02d:%02d", hours, minutes, remainder) : String(format: "%02d:%02d", minutes, remainder)
    }
}
