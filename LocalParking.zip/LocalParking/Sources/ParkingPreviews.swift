#if DEBUG
import Foundation
import SwiftUI

@MainActor
private final class PreviewPersistence: ParkingPersisting {
    var session: ParkingSession?
    init(session: ParkingSession?) { self.session = session }
    func load() throws -> ParkingSession? { session }
    func save(_ session: ParkingSession) throws { self.session = session }
    func clear() throws { session = nil }
}

@MainActor
private final class PreviewServices: ParkingLocating, ParkingGeocoding, MeterNotifying {
    func currentLocation() async throws -> ParkingLocation { Self.location }
    func address(for location: ParkingLocation) async -> String? { "Example Street, San Francisco" }
    func invalidate() {}
    func reconcile(session: ParkingSession?, requestPermission: Bool, isCurrent: @escaping @MainActor () -> Bool) async -> MeterAlertStatus {
        guard let expiry = session?.expiryDate else { return .inactive }
        return expiry > Date() ? .scheduled : .expired
    }
    static var location: ParkingLocation {
        ParkingLocation(latitude: 37.7765, longitude: -122.4167, horizontalAccuracy: 12, capturedAt: Date(), isApproximate: false, address: "Example Street, San Francisco")
    }
}

@MainActor
private func previewStore(parked: Bool, expired: Bool = false) -> ParkingStore {
    let start = Date().addingTimeInterval(-2400)
    let session = parked ? ParkingSession(id: UUID(), parkedAt: start, location: PreviewServices.location, spotDescription: "P4, Level 2\nNear the blue elevator", meter: ParkingMeter(startedAt: start, expiryDate: Date().addingTimeInterval(expired ? -120 : 1200))) : nil
    let services = PreviewServices()
    return ParkingStore(persistence: PreviewPersistence(session: session), locator: services, geocoder: services, notifications: services)
}

#Preview("Ready to park") { ParkingDashboard(store: previewStore(parked: false)) }
#Preview("Parked") { ParkingDashboard(store: previewStore(parked: true)) }
#Preview("Expired · Dark") { ParkingDashboard(store: previewStore(parked: true, expired: true)).preferredColorScheme(.dark) }
#endif
