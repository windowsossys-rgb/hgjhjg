import Foundation
import UserNotifications

/// Copy SDK settings into Sendable values while inside its completion handler.
private struct NotificationPermission: Sendable {
    enum Access: Sendable, Equatable { case notDetermined, denied, allowed, quiet }
    let access: Access
    let hasBannersAndSound: Bool

    init(_ settings: UNNotificationSettings) {
        switch settings.authorizationStatus {
        case .notDetermined: access = .notDetermined
        case .denied: access = .denied
        case .authorized, .ephemeral: access = .allowed
        case .provisional: access = .quiet
        @unknown default: access = .denied
        }
        hasBannersAndSound = settings.alertSetting == .enabled && settings.soundSetting == .enabled
    }
}

enum MeterAlertStatus: Equatable {
    case inactive, expired, scheduled, quiet, permissionRequired, denied, failed

    var message: String? {
        switch self {
        case .inactive, .expired: nil
        case .scheduled: "Meter reminders are scheduled."
        case .quiet: "Reminders are scheduled, but notifications may arrive quietly. Review notification settings for banners and sounds."
        case .permissionRequired: "Enable notifications to receive meter reminders."
        case .denied: "Meter reminders are off. Allow notifications in Settings."
        case .failed: "Your spot is saved, but meter reminders could not be scheduled. Tap Retry."
        }
    }
}

@MainActor
protocol MeterNotifying {
    func invalidate()
    func reconcile(
        session: ParkingSession?,
        requestPermission: Bool,
        isCurrent: @escaping @MainActor () -> Bool
    ) async -> MeterAlertStatus
}

@MainActor
final class MeterNotificationService: MeterNotifying {
    private let center: UNUserNotificationCenter

    init(center: UNUserNotificationCenter = .current()) { self.center = center }

    /// Remove only this feature's alerts; never remove another feature's notifications.
    func invalidate() {
        center.removePendingNotificationRequests(withIdentifiers: MeterAlert.identifiers)
        center.removeDeliveredNotifications(withIdentifiers: MeterAlert.identifiers)
    }

    func reconcile(
        session: ParkingSession?,
        requestPermission: Bool,
        isCurrent: @escaping @MainActor () -> Bool
    ) async -> MeterAlertStatus {
        invalidate()
        guard let session, let expiry = session.expiryDate else { return .inactive }
        guard expiry > Date() else { return .expired }

        var settings = await permission()
        guard isCurrent() else { return .inactive }
        if settings.access == .notDetermined, requestPermission {
            do {
                try await requestAccess()
            } catch { return .failed }
            guard isCurrent() else { return .inactive }
            settings = await permission()
            guard isCurrent() else { return .inactive }
        }

        switch settings.access {
        case .notDetermined: return .permissionRequired
        case .denied: return .denied
        case .allowed, .quiet: break
        }

        let alerts = MeterAlert.plan(for: session, now: Date())
        guard !alerts.isEmpty else { return .expired }
        do {
            for alert in alerts {
                guard isCurrent() else { invalidate(); return .inactive }
                // A permission dialog or scheduling call may have consumed part of the interval.
                guard alert.fireDate.timeIntervalSinceNow > 1 else { continue }
                let content = UNMutableNotificationContent()
                content.title = alert.kind == .fiveMinutes ? "5 minutes left on your meter" : "Your parking meter has expired"
                content.body = alert.kind == .fiveMinutes
                    ? "Head back to your spot or update your reminder after adding meter time."
                    : "Check your meter and return to your saved parking spot."
                content.sound = .default
                content.threadIdentifier = "localparking.meter"
                // Notes and precise coordinates never appear in a lock-screen notification.
                content.userInfo = ["sessionID": session.id.uuidString]

                // An absolute UTC trigger follows the persisted expiry across time-zone changes.
                var calendar = Calendar(identifier: .gregorian)
                calendar.timeZone = TimeZone(secondsFromGMT: 0)!
                let wholeSecond = Date(timeIntervalSince1970: ceil(alert.fireDate.timeIntervalSince1970))
                var components = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: wholeSecond)
                components.calendar = calendar
                components.timeZone = calendar.timeZone
                let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                try await add(UNNotificationRequest(identifier: alert.identifier, content: content, trigger: trigger))
                // An extension/unpark may have happened while add() was suspended.
                guard isCurrent() else { invalidate(); return .inactive }
            }
        } catch {
            // Avoid leaving a half-scheduled pair; foreground reconciliation or Retry can repair it.
            invalidate()
            return .failed
        }
        guard expiry > Date() else { return .expired }
        let quiet = settings.access == .quiet || !settings.hasBannersAndSound
        return quiet ? .quiet : .scheduled
    }

    // Bridge callbacks without sending non-Sendable SDK request/settings objects between actors.
    private func permission() async -> NotificationPermission {
        await withCheckedContinuation { pending in
            center.getNotificationSettings { settings in
                pending.resume(returning: NotificationPermission(settings))
            }
        }
    }

    private func requestAccess() async throws {
        try await withCheckedThrowingContinuation { (pending: CheckedContinuation<Void, any Error>) in
            center.requestAuthorization(options: [.alert, .sound]) { _, error in
                if let error { pending.resume(throwing: error) }
                else { pending.resume() }
            }
        }
    }

    private func add(_ request: UNNotificationRequest) async throws {
        try await withCheckedThrowingContinuation { (pending: CheckedContinuation<Void, any Error>) in
            center.add(request) { error in
                if let error { pending.resume(throwing: error) }
                else { pending.resume() }
            }
        }
    }
}
