import SwiftUI
import UIKit
import UserNotifications

@main
@MainActor
struct LocalParkingApp: App {
    @UIApplicationDelegateAdaptor(ParkingAppDelegate.self) private var appDelegate
    @State private var store = ParkingStore.live()

    var body: some Scene {
        WindowGroup { ParkingDashboard(store: store) }
    }
}

@MainActor
final class ParkingAppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        // Install at launch, before the app can receive a notification callback.
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        // Local alerts also appear while the dashboard is open.
        notification.request.identifier.hasPrefix("localparking.meter.") ? [.banner, .list, .sound] : []
    }
}
