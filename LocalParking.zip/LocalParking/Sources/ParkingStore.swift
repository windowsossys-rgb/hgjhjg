import Foundation
import Observation

struct ParkingIssue: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    var offersSettings = false
}

/// Own a single instance at the app root. Views derive all parking state from one saved session.
@MainActor
@Observable
final class ParkingStore {
    private(set) var session: ParkingSession?
    private(set) var isLocating = false
    private(set) var alertStatus: MeterAlertStatus = .inactive
    private(set) var isUpdatingAlerts = false
    var issue: ParkingIssue?

    var isParked: Bool { session != nil }
    var parkingLocation: ParkingLocation? { session?.location }
    var spotDescription: String { session?.spotDescription ?? "" }
    var expiryDate: Date? { session?.expiryDate }
    var timerDuration: TimeInterval? { session?.timerDuration }

    @ObservationIgnored private let persistence: any ParkingPersisting
    @ObservationIgnored private let locator: any ParkingLocating
    @ObservationIgnored private let geocoder: any ParkingGeocoding
    @ObservationIgnored private let notifications: any MeterNotifying
    @ObservationIgnored private let now: () -> Date
    @ObservationIgnored private var geocodingTask: Task<Void, Never>?
    @ObservationIgnored private var notificationTask: Task<Void, Never>?
    @ObservationIgnored private var notificationRevision = 0
    @ObservationIgnored private var shouldRequestNotificationPermission = false

    init(
        persistence: any ParkingPersisting,
        locator: any ParkingLocating,
        geocoder: any ParkingGeocoding,
        notifications: any MeterNotifying,
        now: @escaping () -> Date = { Date() }
    ) {
        self.persistence = persistence
        self.locator = locator
        self.geocoder = geocoder
        self.notifications = notifications
        self.now = now
        do {
            session = try persistence.load()
        } catch {
            issue = ParkingIssue(title: "Couldn't restore your spot", message: error.localizedDescription)
        }
    }

    static func live() -> ParkingStore {
        ParkingStore(
            persistence: UserDefaultsParkingPersistence(),
            locator: LocationService(),
            geocoder: ReverseGeocoder(),
            notifications: MeterNotificationService()
        )
    }

    /// Snapshot the draft before awaiting GPS. The meter starts only after a successful fix.
    func park(notes: String, duration: TimeInterval?) async {
        guard session == nil, !isLocating else { return }
        isLocating = true
        defer { isLocating = false }
        do {
            if let duration { try ParkingRules.validate(duration: duration) }
            let location = try await locator.currentLocation()
            try Task.checkCancellation()
            let started = now()
            let newSession = ParkingSession(
                id: UUID(),
                parkedAt: started,
                location: location,
                spotDescription: String(notes.trimmingCharacters(in: .whitespacesAndNewlines).prefix(ParkingRules.maximumNoteLength)),
                meter: duration.map { ParkingMeter(startedAt: started, expiryDate: started.addingTimeInterval($0)) }
            )
            try commit(newSession)
            synchronizeAlerts(requestPermission: duration != nil)
            resolveAddress(for: newSession)
        } catch is CancellationError {
            // Cancel means no spot is committed and no notification permission is requested.
        } catch {
            let offersSettings = (error as? ParkingLocationError) == .denied
            issue = ParkingIssue(title: "Couldn't save your spot", message: error.localizedDescription, offersSettings: offersSettings)
        }
    }

    func extendTime(by duration: TimeInterval) {
        guard var updated = session else { return }
        do {
            try updated.extendMeter(by: duration, at: now())
            try commit(updated)
            synchronizeAlerts(requestPermission: true)
        } catch {
            issue = ParkingIssue(title: "Couldn't extend your reminder", message: error.localizedDescription)
        }
    }

    func updateNotes(_ notes: String) {
        guard var updated = session else { return }
        updated.spotDescription = String(notes.trimmingCharacters(in: .whitespacesAndNewlines).prefix(ParkingRules.maximumNoteLength))
        do { try commit(updated) }
        catch { issue = ParkingIssue(title: "Couldn't save notes", message: error.localizedDescription) }
    }

    func unpark() {
        do {
            try persistence.clear()
            geocodingTask?.cancel()
            geocodingTask = nil
            session = nil
            shouldRequestNotificationPermission = false
            synchronizeAlerts(requestPermission: false)
        } catch {
            issue = ParkingIssue(title: "Couldn't clear your spot", message: error.localizedDescription)
        }
    }

    /// Called on launch, foreground entry, and significant clock changes. No automatic permission prompt.
    func refresh() {
        synchronizeAlerts(requestPermission: false)
        if let session, session.location.address == nil, geocodingTask == nil {
            resolveAddress(for: session)
        }
    }

    func enableOrRetryAlerts() { synchronizeAlerts(requestPermission: true) }

    private func commit(_ updated: ParkingSession) throws {
        // Encoding must succeed before the UI announces a saved spot.
        try persistence.save(updated)
        session = updated
    }

    private func resolveAddress(for snapshot: ParkingSession) {
        geocodingTask?.cancel()
        geocodingTask = Task { [weak self, geocoder] in
            let address = await geocoder.address(for: snapshot.location)
            guard !Task.isCancelled, let self, var current = self.session, current.id == snapshot.id else { return }
            self.geocodingTask = nil
            guard let address, !address.isEmpty else { return }
            // Merge into the CURRENT session so a late address cannot undo an extension or note edit.
            current.location.address = address
            do { try self.commit(current) }
            catch {
                self.issue = ParkingIssue(title: "Address wasn't saved", message: "Your coordinates are saved. The address could not be added.")
            }
        }
    }

    private func synchronizeAlerts(requestPermission: Bool) {
        notificationRevision += 1
        shouldRequestNotificationPermission = shouldRequestNotificationPermission || requestPermission
        notifications.invalidate()
        isUpdatingAlerts = true
        guard notificationTask == nil else { return }

        // A single worker serializes notification writes. Every await checks a revision, preventing
        // an older schedule from winning over rapid Extend Time, Clear, or foreground refresh actions.
        notificationTask = Task { [weak self] in
            guard let self else { return }
            while true {
                let revision = self.notificationRevision
                let snapshot = self.session
                let ask = self.shouldRequestNotificationPermission
                self.shouldRequestNotificationPermission = false
                let status = await self.notifications.reconcile(session: snapshot, requestPermission: ask) { [weak self] in
                    self?.notificationRevision == revision
                }
                guard self.notificationRevision == revision else {
                    // Keep explicit permission intent when a passive refresh supersedes it.
                    if ask, snapshot?.id == self.session?.id { self.shouldRequestNotificationPermission = true }
                    continue
                }
                self.alertStatus = status
                self.isUpdatingAlerts = false
                self.notificationTask = nil
                return
            }
        }
    }
}
