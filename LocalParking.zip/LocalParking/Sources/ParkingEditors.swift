import SwiftUI

@MainActor
struct MeterDurationSheet: View {
    let title: String
    let allowsNoMeter: Bool
    let confirmationTitle: String
    let onConfirm: (TimeInterval?) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var useTimer: Bool
    @State private var hours: Int
    @State private var minutes: Int

    init(title: String, initialDuration: TimeInterval?, allowsNoMeter: Bool, confirmationTitle: String, onConfirm: @escaping (TimeInterval?) -> Void) {
        self.title = title
        self.allowsNoMeter = allowsNoMeter
        self.confirmationTitle = confirmationTitle
        self.onConfirm = onConfirm
        let totalMinutes = min(1440, max(1, Int((initialDuration ?? 3600) / 60)))
        _useTimer = State(initialValue: !allowsNoMeter || initialDuration != nil)
        _hours = State(initialValue: totalMinutes / 60)
        _minutes = State(initialValue: totalMinutes % 60)
    }

    private var selectedDuration: TimeInterval { TimeInterval(hours * 3600 + minutes * 60) }

    var body: some View {
        NavigationStack {
            Form {
                if allowsNoMeter {
                    Section {
                        Toggle("Use a meter timer", isOn: $useTimer).tint(.teal)
                    } footer: {
                        Text("Your parking spot can be saved with or without a meter timer.")
                    }
                }
                if useTimer {
                    Section("Quick picks") {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 10) {
                            ForEach([15, 30, 60, 120], id: \.self) { preset in
                                Button {
                                    hours = preset / 60
                                    minutes = preset % 60
                                } label: {
                                    Text(preset < 60 ? "\(preset) min" : "\(preset / 60) hr")
                                        .frame(maxWidth: .infinity, minHeight: 44)
                                }
                                .buttonStyle(.bordered)
                                .tint(selectedDuration == TimeInterval(preset * 60) ? .teal : .secondary)
                                .accessibilityAddTraits(selectedDuration == TimeInterval(preset * 60) ? .isSelected : [])
                            }
                        }
                    }
                    Section("Custom duration") {
                        Picker("Hours", selection: $hours) {
                            ForEach(0...24, id: \.self) { Text("\($0) hours").tag($0) }
                        }
                        Picker("Minutes", selection: $minutes) {
                            ForEach(0...59, id: \.self) { Text("\($0) minutes").tag($0) }
                        }
                        .disabled(hours == 24)
                        Text(selectedDuration > 0 ? ParkingFormat.duration(selectedDuration) : "Choose at least 1 minute")
                            .foregroundStyle(selectedDuration > 0 ? Color.secondary : Color.orange)
                    }
                    Section {
                        Label("Reminders at 5 minutes remaining and at expiry.", systemImage: "bell")
                        Text("If 5 minutes or less remain when alerts are scheduled, only the expiry reminder is added.")
                    }
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    if !allowsNoMeter {
                        Section {
                            Text("Added time starts at the current expiry, or now if the meter has expired. Update or pay the actual meter separately.")
                        }
                        .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        onConfirm(useTimer ? selectedDuration : nil)
                        dismiss()
                    }
                    .bold()
                    .accessibilityLabel(confirmationTitle)
                    .disabled(useTimer && selectedDuration < 60)
                }
            }
            .onChange(of: hours) { _, value in if value == 24 { minutes = 0 } }
        }
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
    }
}

@MainActor
struct ParkingNotesSheet: View {
    @State var notes: String
    let onSave: (String) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("P4, Level 2, near the elevator", text: $notes, axis: .vertical)
                        .lineLimit(4...10)
                        .accessibilityLabel("Parking spot notes")
                } footer: {
                    Text("\(notes.count) / \(ParkingRules.maximumNoteLength) characters")
                }
            }
            .navigationTitle("Spot notes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { onSave(notes); dismiss() }.bold()
                }
            }
            .onChange(of: notes) { _, value in
                if value.count > ParkingRules.maximumNoteLength { notes = String(value.prefix(ParkingRules.maximumNoteLength)) }
            }
        }
        .presentationDetents([.medium, .large])
    }
}
