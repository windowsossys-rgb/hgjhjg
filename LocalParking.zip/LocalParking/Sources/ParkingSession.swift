import Foundation

/// Codable value types keep persistence, timer math, and notification planning independent of UI.
struct ParkingLocation: Codable, Equatable, Sendable {
    let latitude: Double
    let longitude: Double
    let horizontalAccuracy: Double
    let capturedAt: Date
    let isApproximate: Bool
    var address: String?

    var isValid: Bool {
        latitude.isFinite && longitude.isFinite
            && (-90...90).contains(latitude) && (-180...180).contains(longitude)
            && horizontalAccuracy.isFinite && (0...40_100_000).contains(horizontalAccuracy)
            && ParkingRules.isValid(date: capturedAt)
    }
}

struct ParkingMeter: Codable, Equatable, Sendable {
    var startedAt: Date
    var expiryDate: Date

    var duration: TimeInterval { expiryDate.timeIntervalSince(startedAt) }
    var isValid: Bool {
        ParkingRules.isValid(date: startedAt) && ParkingRules.isValid(date: expiryDate)
            && duration.isFinite && duration > 0
    }

    func remaining(at date: Date) -> TimeInterval {
        max(0, expiryDate.timeIntervalSince(date))
    }

    func remainingFraction(at date: Date) -> Double {
        guard duration > 0 else { return 0 }
        return min(1, max(0, remaining(at: date) / duration))
    }

    /// An active meter keeps unused time. An expired meter starts a fresh interval now.
    mutating func extend(by duration: TimeInterval, at date: Date) {
        if expiryDate <= date {
            startedAt = date
            expiryDate = date.addingTimeInterval(duration)
        } else {
            expiryDate = expiryDate.addingTimeInterval(duration)
        }
    }
}

struct ParkingSession: Codable, Equatable, Identifiable, Sendable {
    let id: UUID
    let parkedAt: Date
    var location: ParkingLocation
    var spotDescription: String
    var meter: ParkingMeter?

    var expiryDate: Date? { meter?.expiryDate }
    var timerDuration: TimeInterval? { meter?.duration }
    var isValid: Bool {
        location.isValid && ParkingRules.isValid(date: parkedAt)
            && spotDescription.count <= ParkingRules.maximumNoteLength
            && (meter?.isValid ?? true)
    }

    func elapsed(at date: Date) -> TimeInterval {
        max(0, date.timeIntervalSince(parkedAt))
    }

    mutating func extendMeter(by duration: TimeInterval, at date: Date) throws {
        try ParkingRules.validate(duration: duration)
        if meter != nil {
            meter?.extend(by: duration, at: date)
        } else {
            meter = ParkingMeter(startedAt: date, expiryDate: date.addingTimeInterval(duration))
        }
    }
}

enum ParkingRules {
    static let maximumNoteLength = 500
    static let maximumDuration: TimeInterval = 24 * 60 * 60

    static func isValid(date: Date) -> Bool {
        date.timeIntervalSince1970.isFinite && (Date.distantPast...Date.distantFuture).contains(date)
    }

    /// Each selected interval is 1 minute–24 hours; repeated extensions may exceed 24 hours.
    static func validate(duration: TimeInterval) throws {
        guard duration.isFinite, (60...maximumDuration).contains(duration) else {
            throw ParkingDataError.invalidDuration
        }
    }
}

enum ParkingDataError: LocalizedError {
    case invalidDuration, invalidSession, unreadableSession, unsupportedVersion

    var errorDescription: String? {
        switch self {
        case .invalidDuration: "Choose a meter duration between 1 minute and 24 hours."
        case .invalidSession: "This parking session contains invalid data and could not be saved."
        case .unreadableSession: "Your saved parking data could not be read. Save a new spot to replace it."
        case .unsupportedVersion: "Your saved spot uses a newer data format. Update the app to restore it."
        }
    }
}

/// Pure scheduling policy: never claim there are five minutes left if that threshold has passed.
struct MeterAlert: Equatable, Sendable {
    enum Kind: String, CaseIterable, Sendable { case fiveMinutes, expired }
    let kind: Kind
    let fireDate: Date

    var identifier: String { "localparking.meter.\(kind.rawValue)" }

    static var identifiers: [String] {
        Kind.allCases.map { "localparking.meter.\($0.rawValue)" }
    }

    static func plan(for session: ParkingSession?, now: Date) -> [MeterAlert] {
        guard let expiry = session?.expiryDate else { return [] }
        return [
            MeterAlert(kind: .fiveMinutes, fireDate: expiry.addingTimeInterval(-5 * 60)),
            MeterAlert(kind: .expired, fireDate: expiry)
        ].filter { $0.fireDate.timeIntervalSince(now) > 1 }
    }
}
