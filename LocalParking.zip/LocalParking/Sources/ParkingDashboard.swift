import Combine
import MapKit
import SwiftUI
import UIKit

@MainActor
struct ParkingDashboard: View {
    @Bindable var store: ParkingStore
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.openURL) private var openURL
    @State private var notes = ""
    @State private var duration: TimeInterval?
    @State private var durationSheet: DurationSheetMode?
    @State private var editingNotes = false
    @State private var confirmingUnpark = false
    @State private var parkingTask: Task<Void, Never>?

    private enum DurationSheetMode: String, Identifiable {
        case configure, extend
        var id: String { rawValue }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    if let session = store.session {
                        parkedDashboard(session)
                            .transition(.opacity.combined(with: .move(edge: .bottom)))
                    } else {
                        unparkedDashboard
                            .transition(.opacity.combined(with: .move(edge: .bottom)))
                    }
                }
                .padding(20)
                .frame(maxWidth: 680)
                .frame(maxWidth: .infinity)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("Local Parking")
            .navigationBarTitleDisplayMode(.inline)
            .animation(reduceMotion ? nil : .snappy(duration: 0.3), value: store.isParked)
            .sensoryFeedback(.success, trigger: store.isParked)
            .sheet(item: $durationSheet) { mode in
                MeterDurationSheet(
                    title: mode == .configure ? "Meter reminder" : (store.expiryDate == nil ? "Add a meter" : "Extend time"),
                    initialDuration: mode == .configure ? duration : 30 * 60,
                    allowsNoMeter: mode == .configure,
                    confirmationTitle: mode == .configure ? "Use this duration" : "Update reminder"
                ) { selected in
                    if mode == .configure { duration = selected }
                    else if let selected { store.extendTime(by: selected) }
                }
            }
            .sheet(isPresented: $editingNotes) {
                ParkingNotesSheet(notes: store.spotDescription) { store.updateNotes($0) }
            }
            .confirmationDialog("Clear your saved parking spot?", isPresented: $confirmingUnpark, titleVisibility: .visible) {
                Button("Clear / Unpark", role: .destructive) { store.unpark() }
            } message: {
                Text("This removes your saved location, notes, and meter reminders.")
            }
            .alert(item: $store.issue) { issue in
                if issue.offersSettings {
                    Alert(title: Text(issue.title), message: Text(issue.message),
                          primaryButton: .default(Text("Open Settings"), action: openSettings), secondaryButton: .cancel())
                } else {
                    Alert(title: Text(issue.title), message: Text(issue.message), dismissButton: .default(Text("OK")))
                }
            }
            .task { store.refresh() }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { store.refresh() }
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.significantTimeChangeNotification)) { _ in
                store.refresh()
            }
            .onDisappear { parkingTask?.cancel() }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(store.isParked ? "SPOT SAVED" : "ONE LESS THING TO REMEMBER", systemImage: "parkingsign.circle.fill")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.teal)
            Text(store.isParked ? "Enjoy your time." : "Park. Save. Go.")
                .font(.largeTitle.bold())
                .accessibilityAddTraits(.isHeader)
            Text(store.isParked ? "Your way back is right here." : "Keep your spot and your meter in one place.")
                .foregroundStyle(.secondary)
        }
    }

    private var unparkedDashboard: some View {
        VStack(spacing: 20) {
            ParkingCard {
                VStack(alignment: .leading, spacing: 16) {
                    Label("Remember the details", systemImage: "text.alignleft")
                        .font(.headline)
                    TextField("Spot notes, e.g. P4, Level 2", text: $notes, axis: .vertical)
                        .lineLimit(2...5)
                        .textInputAutocapitalization(.sentences)
                        .padding(12)
                        .background(.quaternary.opacity(0.4), in: RoundedRectangle(cornerRadius: 12))
                        .accessibilityLabel("Parking notes, optional")
                        .onChange(of: notes) { _, value in
                            if value.count > ParkingRules.maximumNoteLength { notes = String(value.prefix(ParkingRules.maximumNoteLength)) }
                        }
                    Button { durationSheet = .configure } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "timer").font(.title2)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Meter reminder").font(.headline)
                                Text(duration.map(ParkingFormat.duration) ?? "No timer · optional")
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 8)
                            Image(systemName: "chevron.right").font(.caption.bold())
                        }
                        .frame(minHeight: 44)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityHint("Choose a preset or custom duration")
                }
            }
            .disabled(store.isLocating)

            Button(action: park) {
                VStack(spacing: 12) {
                    if store.isLocating {
                        ProgressView().controlSize(.large).tint(.white)
                    } else {
                        Image(systemName: "parkingsign.circle.fill").font(.system(size: 58, weight: .medium))
                    }
                    Text(store.isLocating ? "Finding your spot…" : "Park Here").font(.title2.bold())
                    Text(store.isLocating ? "Getting a recent location" : "Save my current location").font(.subheadline)
                }
                .frame(maxWidth: .infinity, minHeight: 170)
                .padding(20)
            }
            .buttonStyle(ParkHereButtonStyle())
            .disabled(store.isLocating)
            .accessibilityHint("Uses your location and saves your notes and optional meter reminder")
            if store.isLocating {
                Button("Cancel location request") { parkingTask?.cancel() }
                    .frame(minHeight: 44)
            }

            Label("Location is requested when you save a spot.", systemImage: "location")
                .font(.footnote).foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func parkedDashboard(_ session: ParkingSession) -> some View {
        VStack(spacing: 20) {
            // A foreground rendering clock only. All math uses stored absolute dates; no background timer.
            TimelineView(.periodic(from: .now, by: 1)) { context in
                ParkingTimeCard(session: session, now: context.date)
            }

            ParkingSpotCard(session: session) { editingNotes = true }

            if session.meter != nil { notificationStatus }

            VStack(spacing: 12) {
                Button(action: openInMaps) {
                    Label("Open in Apple Maps", systemImage: "arrow.triangle.turn.up.right.diamond.fill")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
                .tint(.teal)
                .accessibilityHint("Get walking directions to your saved spot")

                Button { durationSheet = .extend } label: {
                    Label(session.meter == nil ? "Add Meter Timer" : "Extend Time", systemImage: "plus.circle")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.bordered)
                .tint(.teal)

                Button(role: .destructive) { confirmingUnpark = true } label: {
                    Label("Clear / Unpark", systemImage: "parkingsign.circle")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderless)
            }
            Text("Updating the reminder does not pay or extend the physical parking meter.")
                .font(.footnote).foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder
    private var notificationStatus: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            if let expiry = store.expiryDate, expiry > context.date {
                if store.isUpdatingAlerts {
                    HStack {
                        ProgressView()
                        Text("Updating meter reminders…").font(.footnote)
                        Spacer()
                    }
                } else if let message = store.alertStatus.message {
                    ParkingCard {
                        VStack(alignment: .leading, spacing: 10) {
                            Label(message, systemImage: store.alertStatus == .scheduled ? "bell.badge" : "bell.slash")
                                .font(.footnote)
                            if store.alertStatus == .denied || store.alertStatus == .quiet {
                                Button("Notification Settings", action: openSettings).frame(minHeight: 44)
                            } else if store.alertStatus == .permissionRequired || store.alertStatus == .failed {
                                Button(store.alertStatus == .failed ? "Retry" : "Enable notifications") { store.enableOrRetryAlerts() }
                                    .frame(minHeight: 44)
                            }
                        }
                    }
                }
            }
        }
    }

    private func park() {
        guard parkingTask == nil else { return }
        let savedNotes = notes
        let selectedDuration = duration
        parkingTask = Task {
            await store.park(notes: savedNotes, duration: selectedDuration)
            if store.isParked { notes = ""; duration = nil }
            parkingTask = nil
        }
    }

    private func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
    }

    private func openInMaps() {
        guard let session = store.session else { return }
        let location = session.location
        let item: MKMapItem
        if #available(iOS 26.0, *) {
            item = MKMapItem(location: CLLocation(latitude: location.latitude, longitude: location.longitude), address: nil)
        } else {
            item = legacyMapItem(for: location)
        }
        item.name = "My parked car"
        let opened = item.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeWalking])
        if !opened {
            store.issue = ParkingIssue(title: "Couldn't open Maps", message: "Install or enable Apple Maps, then try again.")
        }
    }

    @available(iOS, introduced: 17.0, deprecated: 26.0)
    private func legacyMapItem(for location: ParkingLocation) -> MKMapItem {
        MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)))
    }
}

@MainActor
private struct ParkHereButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(.white)
            .background(LinearGradient(colors: [Color(red: 0.04, green: 0.45, blue: 0.43), Color(red: 0.03, green: 0.28, blue: 0.33)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.98 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.15), value: configuration.isPressed)
    }
}
