import CoreLocation
import Foundation
import MapKit

@MainActor
protocol ParkingLocating {
    func currentLocation() async throws -> ParkingLocation
}

@MainActor
protocol ParkingGeocoding {
    func address(for location: ParkingLocation) async -> String?
}

enum ParkingLocationError: LocalizedError, Equatable {
    case denied, restricted, timedOut, unavailable, alreadyLocating

    var errorDescription: String? {
        switch self {
        case .denied: "Allow location access in Settings to save your parking spot."
        case .restricted: "Location access is restricted on this device. Check device restrictions or contact its administrator."
        case .timedOut: "Your location took too long to arrive. Move to an open area and try again."
        case .unavailable: "A recent location is unavailable. Check Location Services and try again."
        case .alreadyLocating: "A location request is already in progress."
        }
    }
}

/// Initialized on the main actor, so Core Location delivers delegate callbacks on its main run loop.
/// The preconcurrency conformance bridges Core Location's older delegate isolation annotations.
@MainActor
final class LocationService: NSObject, ParkingLocating, @preconcurrency CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private var continuation: CheckedContinuation<ParkingLocation, any Error>?
    private var requestID: UUID?
    private var isRequestingFix = false
    private var timeoutTask: Task<Void, Never>?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
    }

    func currentLocation() async throws -> ParkingLocation {
        guard continuation == nil else { throw ParkingLocationError.alreadyLocating }
        let id = UUID()
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { pending in
                guard !Task.isCancelled else {
                    pending.resume(throwing: CancellationError())
                    return
                }
                continuation = pending
                requestID = id
                handleAuthorization()
            }
        } onCancel: {
            Task { @MainActor [weak self] in
                guard self?.requestID == id else { return }
                self?.finish(.failure(CancellationError()))
            }
        }
    }

    private func handleAuthorization() {
        guard continuation != nil else { return }
        switch manager.authorizationStatus {
        case .notDetermined:
            // Only reached after Park Here; never prompt just because the dashboard appeared.
            manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            guard !isRequestingFix else { return }
            isRequestingFix = true
            manager.requestLocation()
            timeoutTask = Task { [weak self] in
                do { try await Task.sleep(for: .seconds(25)) } catch { return }
                self?.finish(.failure(ParkingLocationError.timedOut))
            }
        case .denied: finish(.failure(ParkingLocationError.denied))
        case .restricted: finish(.failure(ParkingLocationError.restricted))
        @unknown default: finish(.failure(ParkingLocationError.unavailable))
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        handleAuthorization()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard continuation != nil, isRequestingFix else { return }
        let now = Date()
        let candidates = locations.filter {
            CLLocationCoordinate2DIsValid($0.coordinate) && $0.horizontalAccuracy >= 0
                && abs($0.timestamp.timeIntervalSince(now)) <= 30
        }
        guard let fix = candidates.min(by: { $0.horizontalAccuracy < $1.horizontalAccuracy }) else {
            finish(.failure(ParkingLocationError.unavailable))
            return
        }
        finish(.success(ParkingLocation(
            latitude: fix.coordinate.latitude,
            longitude: fix.coordinate.longitude,
            horizontalAccuracy: fix.horizontalAccuracy,
            capturedAt: fix.timestamp,
            isApproximate: manager.accuracyAuthorization == .reducedAccuracy,
            address: nil
        )))
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: any Error) {
        let denied = (error as? CLError)?.code == .denied
        finish(.failure(denied ? ParkingLocationError.denied : ParkingLocationError.unavailable))
    }

    private func finish(_ result: Result<ParkingLocation, any Error>) {
        guard let pending = continuation else { return }
        continuation = nil
        requestID = nil
        isRequestingFix = false
        timeoutTask?.cancel()
        timeoutTask = nil
        manager.stopUpdatingLocation()
        pending.resume(with: result)
    }
}

/// Address lookup is optional and happens AFTER coordinates are saved. Offline parking still works.
@MainActor
final class ReverseGeocoder: ParkingGeocoding {
    func address(for location: ParkingLocation) async -> String? {
        let point = CLLocation(latitude: location.latitude, longitude: location.longitude)
        return await ReverseGeocodingJob().run(for: point)
    }
}

/// Each call owns its request. Cancellation/timeout resumes immediately even if Apple's callback
/// arrives late. Framework request objects stay on the main actor; only text crosses from callbacks.
@MainActor
private final class ReverseGeocodingJob {
    private var continuation: CheckedContinuation<String?, Never>?
    private var cancelRequest: (() -> Void)?
    private var timeoutTask: Task<Void, Never>?

    func run(for point: CLLocation) async -> String? {
        await withTaskCancellationHandler {
            await withCheckedContinuation { pending in
                guard !Task.isCancelled else { pending.resume(returning: nil); return }
                continuation = pending
                timeoutTask = Task { [weak self] in
                    do { try await Task.sleep(for: .seconds(8)) } catch { return }
                    self?.finish(nil)
                }
                if #available(iOS 26.0, *) { startModern(for: point) }
                else { startLegacy(for: point) }
            }
        } onCancel: {
            Task { @MainActor [weak self] in self?.finish(nil) }
        }
    }

    @available(iOS 26.0, *)
    private func startModern(for point: CLLocation) {
        guard let request = MKReverseGeocodingRequest(location: point) else { finish(nil); return }
        cancelRequest = { request.cancel() }
        request.getMapItems { [weak self] items, _ in
            let address = items?.first?.addressRepresentations?.fullAddress(includingRegion: false, singleLine: true)
                ?? items?.first?.name
            self?.finish(address)
        }
    }

    @available(iOS, introduced: 17.0, deprecated: 26.0)
    private func startLegacy(for point: CLLocation) {
        let geocoder = CLGeocoder()
        cancelRequest = { geocoder.cancelGeocode() }
        geocoder.reverseGeocodeLocation(point) { [weak self] placemarks, _ in
            let address = Self.legacyAddress(from: placemarks?.first)
            Task { @MainActor [weak self] in self?.finish(address) }
        }
    }

    @available(iOS, introduced: 17.0, deprecated: 26.0)
    nonisolated private static func legacyAddress(from placemark: CLPlacemark?) -> String? {
        guard let placemark else { return nil }
        let street = [placemark.subThoroughfare, placemark.thoroughfare].compactMap { $0 }.joined(separator: " ")
        let pieces = [street.isEmpty ? placemark.name : street, placemark.locality, placemark.administrativeArea]
        var seen = Set<String>()
        let address = pieces.compactMap { $0 }.filter { !$0.isEmpty && seen.insert($0).inserted }.joined(separator: ", ")
        return address.isEmpty ? nil : address
    }

    private func finish(_ address: String?) {
        guard let pending = continuation else { return }
        continuation = nil
        timeoutTask?.cancel()
        timeoutTask = nil
        let cancel = cancelRequest
        cancelRequest = nil
        cancel?()
        pending.resume(returning: address)
    }
}
