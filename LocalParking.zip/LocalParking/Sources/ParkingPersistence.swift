import Foundation

@MainActor
protocol ParkingPersisting {
    func load() throws -> ParkingSession?
    func save(_ session: ParkingSession) throws
    func clear() throws
}

/// One versioned blob avoids partially updated combinations of isParked, coordinates, and dates.
@MainActor
final class UserDefaultsParkingPersistence: ParkingPersisting {
    private struct Envelope: Codable {
        let version: Int
        let session: ParkingSession
    }

    private let defaults: UserDefaults
    private let key = "localparking.session"

    init(defaults: UserDefaults = .standard) { self.defaults = defaults }

    func load() throws -> ParkingSession? {
        guard let stored = defaults.object(forKey: key) else { return nil }
        guard let data = stored as? Data else { throw ParkingDataError.unreadableSession }
        let envelope: Envelope
        do {
            envelope = try JSONDecoder().decode(Envelope.self, from: data)
        } catch {
            // Keep the original value intact; a later app update may recover it.
            throw ParkingDataError.unreadableSession
        }
        guard envelope.version == 1 else { throw ParkingDataError.unsupportedVersion }
        guard envelope.session.isValid else { throw ParkingDataError.unreadableSession }
        return envelope.session
    }

    func save(_ session: ParkingSession) throws {
        guard session.isValid else { throw ParkingDataError.invalidSession }
        let data = try JSONEncoder().encode(Envelope(version: 1, session: session))
        defaults.set(data, forKey: key)
    }

    func clear() throws { defaults.removeObject(forKey: key) }
}
