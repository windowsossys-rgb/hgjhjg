#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if ! command -v xcodegen >/dev/null 2>&1; then
  if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew is required to install XcodeGen: https://brew.sh" >&2
    exit 1
  fi
  brew install xcodegen
fi

xcodegen generate --spec project.yml
open LocalParking.xcodeproj
