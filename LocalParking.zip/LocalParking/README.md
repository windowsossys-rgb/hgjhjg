**Local Parking Meter & Spot Locator — complete SwiftUI source bundle**

This implementation saves one parking spot, optional notes, and an optional meter reminder. It includes the unparked and parked dashboards, a map preview, Apple Maps walking directions, meter extensions, editable notes, persistence, local notifications, previews, and tests. All application logic is Swift; there are no package dependencies, API keys, image assets, or backend services to configure.

Build with **Xcode 26 or later**, the iOS 26 SDK, **Swift 6 language mode**, and an **iOS 17.0 deployment target**. New MapKit geocoding and map-item APIs are guarded with availability checks; iOS 17–18 use the older equivalents. Observation support starts with iOS 17. [Apple: managing model data](https://developer.apple.com/documentation/swiftui/managing-model-data-in-your-app), [MapKit reverse geocoding](https://developer.apple.com/documentation/mapkit/mkreversegeocodingrequest).

To add it to Xcode:

1. Create an **iOS App** named `LocalParking`, with SwiftUI and Swift. Select Swift Testing if the template offers a test framework choice.
2. Set the deployment target to iOS 17.0 and Swift Language Version to Swift 6. Under Build Settings, set **Default Actor Isolation to Nonisolated** for both app and test targets. Actor ownership is explicitly declared in the source. Leave Approachable Concurrency at its default.
3. Remove the template's app entry point and `ContentView.swift`. Drag the contents of `Sources` into the app target, with **Copy items if needed** selected. There must be exactly one `@main` type.
4. In the app target's **Info** tab, add **Privacy - Location When In Use Usage Description** (`NSLocationWhenInUseUsageDescription`) with the text from `Configuration/Info.plist.example`. Merge that one key; the example is not a complete replacement Info.plist and should not be added as a bundled resource. Core Location requires this purpose string. [Apple: requesting authorization](https://developer.apple.com/documentation/corelocation/requesting-authorization-to-use-location-services).
5. Add `Configuration/PrivacyInfo.xcprivacy` to the app target and confirm it is included in **Copy Bundle Resources**. If the project already has a privacy manifest, merge its UserDefaults entry instead of adding a second manifest. This bundle declares app-private UserDefaults access with reason `CA92.1`. [Apple: required reason APIs](https://developer.apple.com/documentation/bundleresources/app-privacy-configuration/nsprivacyaccessedapitypes/nsprivacyaccessedapitype).
6. Add `Tests` to an **iOS Unit Testing Bundle** target linked to the app; keep these files out of app target membership. If your product module is named differently, replace `@testable import LocalParking` in the three test files.
7. Select your signing team and run on an iPhone or iOS Simulator. For the simulator, choose a simulated location before tapping Park Here. Run tests with **Product → Test**.

The feature needs When In Use location permission and local notification permission. It does not need Always location, Background Modes, Push Notifications, APNs registration, or a notification service extension. Notifications are handed to the system, so the app need not remain running. [Apple: scheduling local notifications](https://developer.apple.com/documentation/usernotifications/scheduling-a-notification-locally-from-your-app).

If you already have an app entry point, keep it and omit `LocalParkingApp.swift`. Create one `@State private var parkingStore = ParkingStore.live()` at the app root and display `ParkingDashboard(store: parkingStore)`. Merge `ParkingAppDelegate`'s notification delegate behavior into your existing delegate. `UNUserNotificationCenter` has a single delegate; preserve any handlers your app already uses. All previews use in-memory services and never request permissions.

The code is organized as follows:

| File | Responsibility |
| --- | --- |
| `Sources/LocalParkingApp.swift` | App root, store lifetime, notification delegate installed at launch, foreground banners. |
| `Sources/ParkingSession.swift` | Codable session/location/meter values, validation, elapsed/countdown math, alert timing policy. |
| `Sources/ParkingPersistence.swift` | Versioned JSON envelope in app-private UserDefaults. |
| `Sources/LocationService.swift` | When In Use authorization, cancellable one-shot GPS request, timeout, optional reverse geocoding. |
| `Sources/MeterNotificationService.swift` | Contextual permission request, five-minute and expiry alerts, cancellation, authorization status. |
| `Sources/ParkingStore.swift` | Main-actor `@Observable` state and coordination of saving, geocoding, notification revisions, and foreground refresh. |
| `Sources/ParkingDashboard.swift` | Dashboard states, actions, scene lifecycle, settings recovery, Maps launch. |
| `Sources/ParkingCards.swift` | Time/progress card, spot map and notes, reusable card, time formatting. |
| `Sources/ParkingEditors.swift` | Preset/custom 1-minute–24-hour duration drawer and notes editor. |
| `Sources/ParkingPreviews.swift` | Interactive unparked, parked, and expired previews with fake services. |
| `Tests/*.swift` | Swift Testing coverage for domain rules, persistence, failures, cancellation, and scheduling races. |

`ParkingStore` exposes the requested state as read-only computed properties: `isParked`, `parkingLocation`, `spotDescription`, `expiryDate`, and `timerDuration`. Its stored `session` is the source of truth. An absent meter has `nil` duration and expiry; an expired meter remains attached to the saved spot until extended or cleared.

When **Park Here** is tapped, the store snapshots the notes and selected duration, validates the duration, and asks `LocationService` for a recent coordinate. The service requests permission only at that point, accepts fixes at most 30 seconds old, and gives the GPS request 25 seconds after authorization. The authorization dialog itself waits for the user's decision; the dashboard also provides Cancel. Requests stop on success, failure, timeout, or cancellation. Reduced-accuracy locations are saved with an approximate-location message. A poor GPS fix does not silently become an exact parking bay. [Apple: one-shot location requests](https://developer.apple.com/documentation/corelocation/cllocationmanager/requestlocation()).

Once the fix arrives, the store writes the entire session as a single JSON envelope, then publishes the parked state. The meter starts at this successful save. Reverse geocoding runs afterward with an eight-second timeout; failure leaves usable coordinates. Late address results merge into the current session by ID, preserving newer notes or extensions. Clearing the session cancels address work. The original saved value is retained if decoding fails, and the dashboard explains the restore error.

The timer uses persisted **absolute dates**. `TimelineView` updates the visible display once per second; it does not drive the underlying countdown or run in the background. Remaining time and progress clamp at zero, and elapsed time remains independent of meter extensions. Changing time zones affects the displayed local time but not the expiry instant. Manually changing the device clock affects absolute-date calculations; significant clock changes trigger foreground notification reconciliation.

An active extension adds time to the previous expiry, preserving unused time. An expired extension starts a fresh interval now, while keeping the original parking start. Adding a meter to a spot without one also starts now. The selected increment is limited to 24 hours; repeated extensions can accumulate a longer interval. The progress bar represents the remaining fraction of the current meter interval, including extensions.

For metered parking, notification permission is requested after the spot is saved. Declining permission leaves the spot and timer intact and shows a Settings action. Two fixed, feature-scoped notification identifiers are used: one for five minutes before expiry and one at expiry. If the five-minute threshold has already passed when scheduling finishes, only the expiry notification is added. A session that is already expired does not generate new historical alerts. System triggers use absolute UTC calendar components, rounded up to the next whole second. Notification delivery remains subject to iOS settings, Focus, and scheduling behavior; the countdown is not an exact-delivery guarantee.

Notification writes run through one serialized worker. Each mutation invalidates existing parking alerts and increments a revision. After every asynchronous notification operation, the worker verifies that its session is still current. Rapid extensions, clearing, or a foreground refresh therefore cannot leave an older schedule as the final result. Launch and foreground refresh reconcile persisted state with permissions without automatically prompting. Only this feature's pending and delivered alerts are removed. Lock-screen alerts contain no parking notes or coordinates. [Apple: notification authorization](https://developer.apple.com/documentation/usernotifications/asking-permission-to-use-notifications), [foreground notification handling](https://developer.apple.com/documentation/usernotifications/unusernotificationcenterdelegate).

**Open in Apple Maps** creates an `MKMapItem` from the saved coordinates and requests walking directions. It works even when reverse geocoding failed. Extending the timer updates this app's reminder only; the dashboard states that the physical parking meter must be handled separately. Clearing requires an in-app confirmation because it removes the saved spot and its reminders.

The interface uses semantic system backgrounds, a teal primary action, SF Symbols, scalable system fonts, scrollable forms, VoiceOver labels, selectable address/notes, and Reduce Motion-aware transitions. Short and long durations, no-meter sessions, expired sessions, loading states, and permission recovery each have a visible state. Product strings are English and ready for extraction into an Xcode String Catalog.

Session data is stored in the app's UserDefaults container and can be included in device backups. Map rendering and address lookup use Apple's services; reverse geocoding can send coordinates to Apple. This implementation adds no analytics or developer-operated data collection. Adapt the privacy manifest and App Store privacy answers if you integrate additional SDKs or services. The file is scoped to the code in this bundle.

Validation performed in this environment: all 13 Swift files passed tree-sitter Swift grammar parsing, and both configuration files passed XML property-list parsing. This was a Windows host with **no Swift compiler, Xcode, or iOS runtime**. No Apple-platform type check, application build, Swift test execution, preview render, or device validation has been performed here. The 22 test declarations (27 cases including duration parameters) are included for execution in Xcode.

Before release, verify the following in Xcode and on a device:

| Check | Expected result |
| --- | --- |
| Build and Product → Test using Swift 6 | App builds and the included tests pass. |
| First Park Here; allow location | One session saves, with notes and a recent coordinate. |
| Deny/restrict location; cancel a pending request | No partial session or meter alerts; a useful recovery message or clean cancellation. |
| Turn Precise Location off | Spot saves and displays an approximate-location explanation. |
| Disable network during address lookup | Coordinates remain saved; lookup ends without blocking the dashboard. |
| Save a timer, force-quit, reopen later | Saved spot, elapsed time, and absolute countdown restore correctly. |
| Save 6 minutes and background the app | Five-minute alert occurs roughly 1 minute later; expiry alert around 6 minutes later. |
| Save 1–5 minutes | Only the expiry alert is scheduled. |
| Deny notifications, then enable in Settings | Parking still works; returning to the app repairs future reminders. |
| Extend repeatedly or clear during permission/scheduling | Only the latest session's future alerts remain; clearing leaves none. |
| Extend after expiry | Countdown restarts from now; parking elapsed time continues. |
| Open Maps after geocoding fails | Walking directions target the saved coordinate. |
| Large accessibility text, VoiceOver, dark mode, Reduce Motion | Content stays reachable and controls remain understandable. |

This is a source bundle for integration into your Xcode project; it does not include an `.xcodeproj`, signing identity, app icon, or App Store metadata.
